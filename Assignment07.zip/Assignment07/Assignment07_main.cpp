// Jaidon Lybbert
// 1.19.19
// Recursive String Reversal

#include<iostream>
using namespace std;

// prints string backwards
void reverseDisplay(const string& s) {
	if(s.length() == 1) cout << s;
	else {
		reverseDisplay(s.substr(1, s.length() + 1));
		cout << s[0];
	}
}


int main() {
	string s, playAgain;
	bool playing = true;
	// loops until user exits
	while(playing == true) {
		// Input
		cout << "Enter a string: ";
		cin >> s;
		// Output
		cout << "The reversed string is: "; reverseDisplay(s); cout << endl;
		cout << "Would you like to try again? [y/n] ";
		// loop to verify user input
		while(playing == true) {
			cin >> playAgain;
			if(playAgain == "y" || playAgain == "Y") {
				break;
			} else if(playAgain == "N" || playAgain == "n") {
				playing = false;
			} else {
				cout << "Invalid input: enter 'y' or 'n': ";
				cin.clear();
				cin.ignore(1000, '\n');
			}
		}
	}
	return 0;
}


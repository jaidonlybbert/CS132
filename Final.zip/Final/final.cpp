// Jaidon Lybbert
// 3/22/19
// Final Exam: Program

#include <iostream>
#include <cmath>
#define PI 3.1415

using namespace std;


class RegularPolygon {
public:
    int numSides;
    double sideLength;
    double angle;
    
    RegularPolygon() {
        numSides = 0;
        sideLength = 0;
        angle = 0;
    }


    RegularPolygon(int numSides) {
        try {
            if (numSides < 3) {
                throw (invalid_argument("Not enough sides!"));
            }
        } catch(invalid_argument err) {
            cout << err.what();
            exit(0);
        }
        
        this->numSides = numSides;
    }
    
    
    RegularPolygon(int numSides, double sideLength) {
        try {
            if (numSides < 3) {
                throw (invalid_argument("Can't have negative sides!"));
            }
            
            if (sideLength < 0) {
                throw (invalid_argument("Sides can't be a negative length!"));
            }

        } catch(invalid_argument err) {
            cout << err.what();
            exit(0);
        }
        
        this->numSides = numSides;
        this->sideLength = sideLength;
    }
    
    
    double getPerimeter() { return numSides * sideLength; }
    
    
    virtual double getArea() { return (sideLength * sideLength * sqrt(3)) / 4; }
    
    
    virtual double getAngle() { return ( (PI * (numSides - 2)) / numSides) * (180 / PI); }
    
    
    virtual void printAttributes() {
        cout << "These are the characteristics of the regular polygon:\n"
             << "Number of sides: " << numSides << endl
             << "Side length: " << sideLength << endl
             << "Perimeter: " << getPerimeter() << endl
             << "Area: " << getArea() << endl
             << "Interior angle: " << getAngle() <<  " degrees" << endl;
    }
};


class EquilateralTriangle : public RegularPolygon {
    double semiperimeter;
public:
    EquilateralTriangle(double sideLength) : RegularPolygon(3) {
        try {
            if (sideLength < 0) {
                throw (invalid_argument("Side length's can't be negative!"));
            }
        } catch(invalid_argument err) {
            cout << err.what();
            exit(0);
        }
        
        this->sideLength = sideLength;
        semiperimeter = (sideLength * 3) / 2;
    }
    
    double getArea() {
        return sqrt(semiperimeter * pow((semiperimeter - sideLength), 3));
    }
    
    
    double getAngle() { return 60; };
    
    void printAttributes() {
        cout << "These are the characteristics of the Equilateral Triangle:\n"
             << "Number of sides: " << numSides << endl
             << "Side length: " << sideLength << endl
             << "Perimeter: " << getPerimeter() << endl
             << "Semi-perimeter: " << semiperimeter << endl
             << "Area: " << getArea() << endl
             << "Interior angle: " << getAngle() << " degrees" << endl;
    }
};


class Square: public RegularPolygon {
public:
    Square(double sideLength) : RegularPolygon(4) {
        try {
            if (sideLength < 0) {
                throw (invalid_argument("Side length's can't be negative!"));
            }
        } catch(invalid_argument err) {
            cout << err.what();
            exit(0);
        }
        
        this->sideLength = sideLength;
    }
    
    double getArea() { return sideLength * sideLength; }
    
    double getAngle() { return 90; }
    
    void printAttributes() {
        cout << "These are the characteristics of the Square:\n"
             << "Number of sides: " << numSides << endl
             << "Side length: " << sideLength << endl
             << "Perimeter: " << getPerimeter() << endl
             << "Area: " << getArea() << endl
             << "Interior angle: " << getAngle() << " degrees" << endl;
    }
};


class RegularPentagon : public RegularPolygon {
public:
    RegularPentagon(double sideLength) : RegularPolygon(5) {
        try {
            if (sideLength < 0) {
                throw (invalid_argument("Side length's can't be negative!"));
            }
        } catch(invalid_argument err) {
            cout << err.what();
            exit(0);
        }

        this->sideLength = sideLength;
    }

  //  double getArea() { return ( (1 / 4) * sqrt( 5 * (5 + (2 * sqrt(5)) ) ) * sideLength * sideLength ); }
    
    double getAngle() { return 540 / 5; }

    void printAttributes() {
        cout << "These are the characteristics of the Regular Pentagon:\n"
             << "Number of sides: " << numSides << endl
             << "Side length: " << sideLength << endl
             << "Perimeter: " << getPerimeter() << endl
             << "Area: " << getArea() << endl
             << "Interior angle: " << getAngle() << " degrees" << endl;
    }

};


int main() {
    int numSides;
    double sideLength;
    
    cout << "Enter a number of sides: ";
    cin >> numSides;
    
    cout << "Enter the length of the sides: ";
    cin >> sideLength;
    
    cout << endl;
    
    if (numSides == 3) {
        EquilateralTriangle* triangle = new EquilateralTriangle(sideLength);
        triangle->printAttributes();
        delete triangle;
    } else if (numSides == 4) {
        Square* square = new Square(sideLength);
        square->printAttributes();
        delete square;
    } else if (numSides == 5) {
        RegularPentagon* pentagon = new RegularPentagon(sideLength);
        pentagon->printAttributes();
        delete pentagon;
    } else {
        RegularPolygon* polygon = new RegularPolygon(numSides, sideLength);
        polygon->printAttributes();
        delete polygon;
    }

    return 0;
}
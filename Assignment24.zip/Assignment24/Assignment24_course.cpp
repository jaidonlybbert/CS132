#include<iostream>
#include "course.h"

using namespace std;


string* increaseSize(const string* array, const int size, const int newSize) {
    string *p;
    p = new string[newSize];

    if (!(size < newSize)) {
        delete [] array;
        return NULL;
    }

    for (int i = 0; i < size; i++) {
        *(p + i) = *(array + i);
    }

    delete [] array;
    return p;
}


Course::Course(const string &courseName, const int capacity) {
    name = courseName;
    numStudents = 0;
    this->capacity = capacity;
    students = new string[capacity];
}


Course::~Course() {
    delete [] students;
    students = NULL;
}


string Course::getName() const {
    return name;
}


int Course::getNumStudents() const {
    return numStudents;
}


void Course::addStudent(const string studentName) {
    while(true) {
        for (int i = 0; i < capacity; i++) {
            if (*(students + i) == "") {
                *(students + i) = studentName;
                numStudents++;
                return;
            }
        }
        students = increaseSize(students, capacity, (capacity + 5));
        capacity += 5;
        cout << "Class size has been expanded to " << capacity << endl;
    }
}


void Course::printStudents() const {
    cout << "\nStudents:\n";
    for (int i = 0; i < capacity; i++) {
        cout << i + 1 << ": " << *(students + i) << endl;
    }
    cout << endl;
}

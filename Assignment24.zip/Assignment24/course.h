#ifndef COURSE
#define COURSE

class Course {
    std::string name;
    int numStudents, capacity;
    std::string* students;
public:
    Course(const std::string &name, const int capacity);
    ~Course();
    std::string getName() const;
    int getNumStudents() const;
    void addStudent(const std::string studentName);
    void printStudents() const;
    int getEnrolled() const;
};

#endif

// Jaidon Lybbert
// February 15, 2019
// Assignment 24: The Course Class
#include<iostream>
#include "course.h"

using namespace std;


int main() {
    string studentName;

    Course physics("Physics", 3);

    for (int i = 0; i < 5; i++) {
        cout << "Enter student's name: ";
        cin >> studentName;
        physics.addStudent(studentName);
    }

    cout << "\n\nCourse: " << physics.getName() << endl;
    cout << "Number of students: " << physics.getNumStudents() << endl;
    physics.printStudents();

    return 0;
}

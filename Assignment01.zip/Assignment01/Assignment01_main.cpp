// Jaidon Lybbert
// 1.7.19
// Assignment 01: Sum Elements Column by Column

#include <iostream>
#include <vector>
using namespace std;

int main() {
	vector<vector<int> > matrix;
	vector<int> row;
	int sums[4];

	// assign initial values of elements in "sums"
	for(int i; i < 4; i++) {
		sums[i] = 0;
	}

	// prompt
	cout << "Enter a 3-by-4 matrix row by row: " << endl;

	// input
	int a;
	for(int i = 0; i < 3; i++) {
		row.clear();
		for(int j = 0; j < 4; j++) {
			cin >> a;
			row.push_back(a);
		}
		matrix.push_back(row);
	}

	// add all elements of each column and store in 'sums' array
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 3; j++) {
			sums[i] += matrix[j][i];
		}
	}

	// output
	for(int i = 0; i < 4; i++) {
		cout << "The sum of column " << i + 1 << " is " << sums[i] << endl;
	}

	return 0;
}



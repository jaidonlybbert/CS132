// Jaidon Lybbert
// 1.19.19
// Assignment 08: Sum the Digits in an Integer

#include<iostream>
using namespace std;


//-Add all digits in an integer
int sumDigits(int number) {
	if(number < 10) return number;
	else return ((number % 10) + sumDigits((number - (number % 10)) / 10));
}


int main() {
	string playAgain;
	int inputInt;
	bool playing = true;
//-Repeatedly call sumDigits function
	while(playing == true) {
//--Call sumDigits function
	//--Input
		cout << "Enter a positive integer: ";
		cin >> inputInt;
		if(!cin || inputInt < 0) {
			cout << "Invalid input, must be a positive integer!\n";
			cin.clear();
			cin.ignore(1000, '\n');
			continue;
		}
	//--Output
		cout << "The sum of the digits is: " << sumDigits(inputInt) << endl;
		cout << "Would you like to try again? [y/n] ";
//--Ask user if they want to loop again
		while(playing == true) {
			cin >> playAgain;
			if(playAgain == "y" || playAgain == "Y") {
				break;
			} else if(playAgain == "N" || playAgain == "n") {
				playing = false;
			} else {
				cout << "Invalid input: enter 'y' or 'n': ";
				cin.clear();
				cin.ignore(1000, '\n');
			}
		}
	}
	return 0;
}


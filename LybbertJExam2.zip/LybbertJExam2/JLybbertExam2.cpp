// Jaidon Lybbert
// February 28, 2019
// Exam 02

#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <vector>

using namespace std;


class Circle {
	double radius;

public:
	Circle() {
		radius = 1.0;
	}

	Circle(double radius) {
		this->radius = radius;
	}

	double getRadius() {
		return radius;
	}

	double getArea() {
		return (pow(radius, 2) * 3.14);
	}
};


class Cylinder {
	double height;
	Circle base;

public:
	Cylinder() {
		height = 1.0;
	}

	Cylinder(double height) {
		this->height = height;
	}

	Cylinder(double height, Circle base) {
		this->height = height;
		this->base = base;
	}

	double getHeight() { return height; }
	double getRadius() { return base.getRadius(); }
	Circle getBase() { return base; }

	double getVolume() { return(base.getArea() * height); }
	double getSurfaceArea() { return((base.getArea() * 2) + (2 * base.getRadius() * 3.14 * height)); }
};


int main() {
	string keepGoing = "y";
	int randInt;
	srand(time(NULL));
	vector<Cylinder*> cylinders;
	Cylinder* cylinderPointer;

	// Create cylinders
	while (keepGoing == "y" || keepGoing == "Y") {
		randInt = rand() % 3;

		if (randInt == 0) {
			cylinderPointer = new Cylinder();
		}

		else if (randInt == 1) {
			cylinderPointer = new Cylinder(rand() % 10 + 1);
		}

		else if (randInt == 2) {
			cylinderPointer = new Cylinder(rand() % 10 + 1, Circle(rand() % 10 + 1));
		}

		cylinders.push_back(cylinderPointer);
		cout << "Cylinder created; keep going? (y/n) " << endl;
		cin >> keepGoing;
	}

	cout << endl;

	// Print cylinders
	for (int i = 0; i < cylinders.size(); i++) {
		cout << "Cylinder " << i + 1 << ":\n";
		cout << "Radius: " << cylinders[i]->getRadius() << endl;
		cout << "Height: " << cylinders[i]->getHeight() << endl;
		cout << "Surface Area: " << cylinders[i]->getSurfaceArea() << endl;
		cout << "Volume: " << cylinders[i]->getVolume() << endl << endl;
	}

	return 0;
}
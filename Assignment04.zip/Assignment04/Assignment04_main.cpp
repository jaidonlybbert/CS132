// Jaidon Lybbert
// 1.11.19
// Assignment 04: Connect 4

#include<iostream>
#include<vector>
#include<ctime>
using namespace std;

bool hasFlag;

void flaggerHorizontal(const vector<vector<int> > &matrix) {
	vector<vector<int> > flaggedH;
	for(int i = 0; i < matrix.size(); i++) {
		for(int j = 0; j < matrix[0].size(); j++) {
			// check if current position has already been flagged
			hasFlag = false;
			for(int l = 0; l < flaggedH.size(); l++) {
				if(flaggedH[l][0] == i && flaggedH[l][1] == j) {
					hasFlag = true;
				}
			}
			if(hasFlag) continue;

			// check for horizontal matches
			int b = j;
			while((b + 1) < matrix[0].size() && matrix[i][b] == matrix[i][b + 1]) {
				b++;
			}
			// if there are horizontal matches flag those coordinates
			if((b - j) > 2) {
				for(int k = 0; k <= (b - j); k++) {
					flaggedH.push_back({i, (j + k)});
				}
			}
		}
	}

	// print matrix with flagged numbers
	cout << endl << "Horizontal:\n";
	for(int i = 0; i < matrix.size(); i++) {
		for(int j = 0; j < matrix[0].size(); j++) {
			hasFlag = false;
			for(int k = 0; k < flaggedH.size(); k++) {
				if(i == flaggedH[k][0] && j == flaggedH[k][1]) {
					hasFlag = true;
				}
			}
			if(hasFlag) {
				cout << "'" << matrix[i][j] << "'";
			} else {
				cout << " " << matrix[i][j] << " ";
			}
		}
		cout << endl;
	}
}


void flaggerDiagonal(const vector<vector<int> > &matrix) {
	vector<vector<int> > flaggedDR, flaggedDL;
	for(int i = 0; i < matrix.size(); i++) {
		for(int j = 0; j < matrix[0].size(); j++) {
			// check if current position has already been flagged
			hasFlag = false;
			for(int l = 0; l < flaggedDR.size(); l++) {
				if(flaggedDR[l][0] == i && flaggedDR[l][1] == j) {
					hasFlag = true;
				}
			}
			for(int l = 0; l < flaggedDL.size(); l++) {
				if(flaggedDL[l][0] == i && flaggedDL[l][1] == j) {
					hasFlag = true;
				}
			}
			if(hasFlag) continue;

			// check for diagonal matches
			int c = i;
			int d = j;
			while((c + 1) < matrix.size() && (d + 1) < matrix[0].size() &&
				 matrix[c][d] == matrix[c + 1][d + 1]) {
				c++;
				d++;
            }
            int e = i;
            int f = j;
            while((e + 1) < matrix.size() && (f - 1) >= 0 &&
            	 matrix[e][f] == matrix[e + 1][f - 1]) {
            	e++;
            	f--;
            }

            // add match coordinates to vector
			if((c - i) > 2) {
				for(int k = 0; k <= (c - i); k++) {
					flaggedDR.push_back({(i + k), (j + k)});
				}
			}
			if((e - i) > 2) {
				for(int k = 0; k <= (e - i); k++) {
					flaggedDL.push_back({(i + k),(j - k)});
				}
			}
		}
	}
	// print matrix with flagged coordinates
	cout << endl << "Diagonal:\n";
	for(int i = 0; i < matrix.size(); i++) {
		for(int j = 0; j < matrix[0].size(); j++) {
			hasFlag = false;
			for(int k = 0; k < flaggedDR.size(); k++) {
				if(i == flaggedDR[k][0] && j == flaggedDR[k][1]) {
					hasFlag = true;
				}
			}
			for(int k = 0; k < flaggedDL.size(); k++) {
				if(i == flaggedDL[k][0] && j == flaggedDL[k][1]) {
					hasFlag = true;
				}
			}
			if(hasFlag) {
				cout << "'" << matrix[i][j] << "'";
			} else {
				cout << " " << matrix[i][j] << " ";
			}
		}
		cout << endl;
	}
}


void flaggerVertical(const vector<vector<int> > &matrix) {
	vector<vector<int> > flaggedV;
	for(int i = 0; i < matrix.size(); i++) {
		for(int j = 0; j < matrix[0].size(); j++) {
			// check if current position has already been flagged
			hasFlag = false;
			for(int l = 0; l < flaggedV.size(); l++) {
				if(flaggedV[l][0] == i && flaggedV[l][1] == j) {
					hasFlag = true;
				}
			}
			if(hasFlag) continue;

			// check for vertical matches
			int a = i;
			while((a + 1) < matrix.size() && matrix[a][j] == matrix[a + 1][j]) {
				a++;
			}
			
			// if there are vertical matches flag those coordinates
			if((a - i) > 2) {
				for(int k = 0; k <= (a - i); k++) {
					flaggedV.push_back({(i + k), j});
				}
			}
		}
	}
	// print matrix with flagged elements
	cout << endl << "Vertical:\n";
	for(int i = 0; i < matrix.size(); i++) {
		for(int j = 0; j < matrix[0].size(); j++) {
			hasFlag = false;
			for(int k = 0; k < flaggedV.size(); k++) {
				if(i == flaggedV[k][0] && j == flaggedV[k][1]) {
					hasFlag = true;
				}
			}
			if(hasFlag) {
				cout << "'" << matrix[i][j] << "'";
			} else {
				cout << " " << matrix[i][j] << " ";
			}
		}
		cout << endl;
	}
}


// take and verify user input
int userInput() {
	int a;
	while(true) {
		cin >> a;
		if(!cin || a < 4 || a > 20) {
			cout << "Invalid input: must be an integer in range 4-20.\n";
			cin.clear();
			cin.ignore(1000, '\n');
			continue;
		} else {
			return a;
		}
	}
}


// print raw matrix
void printMatrix(const vector<vector<int> > &matrix) {
	cout << "\nMatrix:\n";
	for(int i = 0; i < matrix.size(); i++) {
		cout << " ";
		for(int j = 0; j < matrix[0].size(); j++) {
			cout << matrix[i][j] << "  ";
		}
		cout << "\n";
	}
}


// generate random matrix
void matrixGenerator(vector<vector<int> > &matrix, vector<int> &temp, int rows, int columns) {
	int a;
	for(int i = 0; i < rows; i++) {
		for(int j = 0; j < columns; j++) {
			a = rand() % 3 + 1;
			temp.push_back(a);
		}
		matrix.push_back(temp);
		temp.clear();
	}
}


int main() {
	vector<vector<int> > matrix;
	vector<int> temp;
	int rows, columns;
	srand(time(NULL));

	cout << "Enter number of rows for the matrix: ";
	rows = userInput();
	cout << "Enter number of columns for the matrix: ";
	columns = userInput();

	matrixGenerator(matrix, temp, rows, columns);
	printMatrix(matrix);
	flaggerVertical(matrix);
	flaggerHorizontal(matrix);
	flaggerDiagonal(matrix);

	return 0;
}
	

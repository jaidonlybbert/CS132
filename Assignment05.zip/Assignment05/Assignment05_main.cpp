// Jaidon Lybbert
// 1.17.19
// Greatest Common Denominator

#include<iostream>
using namespace std;


// Finds greatest common denominator between x and y
int gcd(int x, int y) {
	if(y == 0) return x;
	else return(gcd(y, x % y));
}


// Takes and verifies user input
int userInput() {
	int input;
	while(true) {
		cin >> input;
		if(!cin || input < 0) {
			cout << "Invalid input: must be integer greater than 0.\n";
			cin.clear();
			cin.ignore(1000, '\n');
			continue;
		}
		return input;
	}
}
	

int main() {
	int x, y;
	// Input
	cout << "Enter first number (greater than 0): ";
	x = userInput();
	cout << "Enter second number (greater than 0): ";
	y = userInput();
	// Output
	cout << "The greatest common divisor is: " << gcd(x, y);
	return 0;
}


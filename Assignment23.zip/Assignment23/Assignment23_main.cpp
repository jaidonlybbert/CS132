// Jaidon Lybbert
// February 15, 2019
// Assignment 23: Increase Array Size
#include<iostream>

using namespace std;


int* increaseSize(const int* array, const int size, const int newSize) {
    int *p;
    p = new int[newSize];

    if (!(size < newSize)) {
        delete [] array;
        return NULL;
    }

    for (int i = 0; i < size; i++) {
        *(p + i) = *(array + i);
    }

    delete [] array;
    return p;
}


int main() {
    srand(time(NULL));
    int* p;
    int size = 10;
    double sum = 0;
    p = new int[size];

    for (int i = 0; i < size; i++) {
        *(p + i) = (rand() % 10) + 1;
        sum += *(p + i);
    }

    p = increaseSize(p, size, 20);

    for (int i = 9; i < 20; i++) {
        *(p + i) = (rand() % 10) + 1;
        sum += *(p + i);
    }

    delete [] p;
    p = NULL;

    cout << "Average: " << sum / 20 << endl;

    return 0;
}

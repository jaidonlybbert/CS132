// Jaidon Lybbert
// 1.17.19
// Assignment 06: Sum Series

#include<iostream>
using namespace std;


// solve summation through recursion
double summationRecurse(double n) {
	if(n==0) return 0;
	else {
		return ((n / ((2 * n) + 1)) + summationRecurse(n-1));
	}
}


// solve summation through looping
double summationLoop(int n) {
	double sum = 0;
	for(double i = 0; i < n; i++) {
		sum += (i + 1) / (((i + 1) * 2) + 1);
	}
	return sum;
}


int userInput() {
	int input;
	while(true) {
		cout << "Enter a value of n for the summation: ";
		cin >> input;
		if(!cin || input < 0) {
			cout << "Invalid input: must be integer greater than 0.\n";
			cin.clear();
			cin.ignore(1000, '\n');
			continue;
		}
		return input;
	}
}


int main() {
	double a;
	// Input
	a = userInput();
	// Output
	cout << "Summation solved through recursion: " << summationRecurse(a)
		 << endl << "Summation solved through looping: "
		 << summationLoop(a) << endl;
	return 0;
}


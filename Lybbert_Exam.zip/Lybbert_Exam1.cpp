// Jaidon Lybbert
// Exam 1 Program

#include <iostream>
#include <ctime>
using namespace std;

class Player {
    string name;
    string playerClass;
    int level;
    
    public:
        void increaseLevel() {
            if(level < 10) {
                level++;   
            }
        }
        
        void setLevel(int inputLevel) {
            level = inputLevel;
        }
        
        string getName() {
            return name;
        }
        
        string getPlayerClass() {
            return playerClass;
        }
        
        int getLevel() {
            return level;
        }
        
        Player() {
            name = "Player";
            playerClass = "warrior";
            level = 1;
        }
        
        Player(string inputName, string inputClass) {
            name = inputName;
            playerClass = inputClass;
            level = 1;
        }
};

int sumInteger(int n) {
    if (n < 10) { return n; }
    else {
        return((n % 10) + sumInteger((n - (n % 10)) / 10));
    }
}

int main() {
    srand(time(NULL));
    int array[20][20];
    int count5 = 0;
    string inputName, inputClass;
    int inputInt;

    // Array
    for(int i = 0; i < 20; i++) {
        for(int j = 0; j < 20; j++) {
            array[i][j] = rand() % 10;
            if(array[i][j] == 5) {
                count5++;
            }
            cout << array[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl << "There are " << count5 << " fives in the array.\n\n";
    
    // Sum integer
    cout << "Enter an integer: ";
    cin >> inputInt;
    cout << "The sum of digits is: " << sumInteger(inputInt) << "\n\n";

    // Player class
    cout << "Enter a name: ";
    cin >> inputName;
    cout << endl;
    cout << "Enter a class type: ";
    cin >> inputClass;
    cout << endl;
    Player player1(inputName, inputClass);
    player1.increaseLevel();
    cout << "The name is: " << player1.getName();
    cout << "\nThe class is: " << player1.getPlayerClass();
    cout << "\nThe level is: " << player1.getLevel() << endl << endl;
    return 0;
}
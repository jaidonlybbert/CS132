// Jaidon Lybbert
// February 15, 2019
// Assignment 22: Array Functions with Pointers
#include<iostream>
#include<ctime>

using namespace std;


int findSmallest(const int* intArray, const int size) {
    int smallest = 1000;

    for (int i = 0; i < size; i++) {
        if (*(intArray + i) < smallest) {
            smallest = *(intArray + i);
        }
    }

    return smallest;
}


int findLargest(const int* intArray, const int size) {
    int largest = -1000;

    for (int i = 0; i < size; i++) {
        if (*(intArray + i) > largest) {
            largest = *(intArray + i);
        }
    }

    return largest;
}


 int main() {
     srand(time(NULL));
     int size;

     cout << "Enter size of array: ";
     cin >> size;

     int* p;
     p = new int[size];

     for (int i = 0; i < size; i++) {
         *(p + i) = rand() % 1001;
         if (rand() % 2 == 0) {
             *(p + i) *= -1;
         }
     }

     cout << endl << "Smallest number: " << findSmallest(p, size) << endl;
     cout << "Largest number: " << findLargest(p, size) << endl;
     return 0;
 }

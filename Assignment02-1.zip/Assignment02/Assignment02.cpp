// Jaidon Lybbert
// 1.8.19
// Assignment 02: Add two matrices

#include<iostream>
#include<vector>
using namespace std;

// adds the matrices together, and stores result in matrix3
void addMatrices(const vector<vector<int> > &matrix1,
	 const vector<vector<int> > &matrix2, vector<int> &temp,
	 vector<vector<int> > &matrix3) {
	int sum;
	// for each row
	for(int i = 0; i < 3; i++) {
		temp.clear();
		// for each column
		for(int j = 0; j < 3; j++) {
			// sum numbers at current element
			sum = matrix1[i][j] + matrix2[i][j];
			// append sums into temporary array
			temp.push_back(sum);
		}
		// append lists of sums into matrix3
		matrix3.push_back(temp);
	}
}

// handles user input
void enterMatrix(vector<vector<int> > &matrix, vector<int> &temp) {
	int a;
	for(int i = 0; i < 3; i++) {
		temp.clear();
		for(int j = 0; j < 3; j++) {
			cin >> a;
			temp.push_back(a);
		}
		matrix.push_back(temp);
	}
}
			

int main() {
	vector<vector<int> > matrix1, matrix2, matrix3;
	vector<int> temp;

	// input
	cout << "Enter 3-by-3 matrix 1:\n";
	enterMatrix(matrix1, temp);
	cout << "Enter 3-by-3 matrix 2:\n";
	enterMatrix(matrix2, temp);
	
	// add matrices
	addMatrices(matrix1, matrix2, temp, matrix3);
	
	// output
	cout << "The sum of the matrices is:\n";
	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			cout << matrix3[i][j] << " ";
		}
		cout << endl;
	}
	
	return 0;
}


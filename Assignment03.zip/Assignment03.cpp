// Jaidon Lybbert
// 1.11.19
// Assignment 03: Identical Arrays

#include<iostream>
#include<vector>
using namespace std;


// counts occurences compares the 2d matrices stored in 3d 'matrix'
bool compareMatrices(const int (&matrix)[2][3][3]) {
	// format: [occurences matrix][occurences]
	int occurences[2][101] = {0};

	for(int k = 0; k < 2; k++) {
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				// store number of occurences in 2d matrix
				occurences[k][matrix[k][i][j]]++;
			}
		}
	}

	// compares the matrices in the 2d 'occurences' matrix; check if they match
	for(int i = 0; i < 101; i++) {
		if(occurences[0][i] != occurences[1][i]) {
			return false;
		}
	}
	return true;
}


// handles user input, stores values in matrix
void enterMatrix(int (&matrix)[2][3][3], int outerMatrix) {
	int a;
	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			while(true) {
				// verify that the input is an integer
				cin >> a;
				if(!cin) {
					cout << "Invalid input: must be integer in range 0-100.\n";
					cin.clear();
					cin.ignore(1000, '\n');
					continue;
				}
				// verify that the input is in specified range
				if(a < 0 || a > 100) {
					cout << "Invalid input: must be in range 0-100.\n";
				} else {
					break;
				}
			}
			matrix[outerMatrix][i][j] = a;
		}
	}
}
		

int main() {
	// format: [matrix for comparison][row][column]
	int matrix[2][3][3] = {0};

	// input
	cout << "Enter 3-by-3 matrix 1 (valid numbers in range 0-100):\n";
	enterMatrix(matrix, 0);
	cout << "Enter 3-by-3 matrix 2 (valid numbers in range 0-100):\n";
	enterMatrix(matrix, 1);

	// output
	if(compareMatrices(matrix)) {
		cout << "The matrices match!\n";
	} else {
		cout << "The matrices do not match!\n";
	}

	return 0;
}

